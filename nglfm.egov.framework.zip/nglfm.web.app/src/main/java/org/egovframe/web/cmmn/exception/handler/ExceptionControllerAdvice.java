package org.egovframe.web.cmmn.exception.handler;

import java.net.SocketTimeoutException;
import java.util.Locale;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.UnexpectedTypeException;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.egovframe.rte.fdl.cmmn.exception.EgovBizException;
import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.egovframe.web.cmmn.aop.vo.RestResponse;
import org.egovframe.web.cmmn.exception.BaseException;
import org.egovframe.web.cmmn.exception.BizDuplicateException;
import org.egovframe.web.cmmn.exception.BizException;
import org.egovframe.web.cmmn.exception.EgovXssException;
import org.egovframe.web.cmmn.exception.ForbiddenException;
import org.egovframe.web.cmmn.exception.InterfaceException;
import org.egovframe.web.cmmn.exception.NotFoundException;
import org.egovframe.web.cmmn.exception.UnauthorizedException;
import org.egovframe.web.cmmn.exception.ValidationException;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.dao.DataAccessException;
import org.springframework.data.util.Pair;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.HttpSessionRequiredException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.NoHandlerFoundException;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
 
/**
 * <pre>
 * Controller에 대한 Exception 처리하는 Advice
 * </pre>
 */
@Slf4j
@ControllerAdvice
public class ExceptionControllerAdvice {

	/** 전자정부 Property 확장 **/
	@Resource(name="propertiesService")
	protected EgovPropertyService propertiesService;
	
	@Resource(name = "messageSource")
	private MessageSource messageSource;
	  
    /**
     * Not Found (NotFoundException)에 대한 핸들러
     */
    @ExceptionHandler(NotFoundException.class)
    public Object notFoundHandle(NotFoundException ex, HttpServletRequest request, HttpServletResponse response) {
        ExceptionInfo info = new ExceptionInfo(ex);

        if (StringUtils.isBlank(info.getUserMessage())) {
            info.setUserMessage(messageSource.getMessage("nglfm.common.exception.notfound",null,Locale.KOREA));
            info.setUserMessage(ex.getMessage());
        }
        log.debug("info.getUserMessage() >> "+info.getUserMessage());
        info.setHttpStatus(HttpStatus.NOT_FOUND);

        return makeResponse(info, request, response);
    }

    /**
     * Not Found (NoHandlerFoundException)에 대한 핸들러
     */
    @ExceptionHandler(NoHandlerFoundException.class)
    public ResponseEntity<?> notFoundNoHandlerHandle(NoHandlerFoundException ex, HttpServletRequest request,
            HttpServletResponse response) {
    	log.debug("notFoundNoHandlerHandle(NoHandlerFoundException ex, HttpServletRequest request,\n" + 
    			"            HttpServletResponse response)");
        ExceptionInfo info = new ExceptionInfo(ex);

        if (StringUtils.isBlank(info.getUserMessage())) {
            info.setUserMessage(messageSource.getMessage("nglfm.common.exception.notfound",null,Locale.KOREA));
        }
        info.setHttpStatus(HttpStatus.NOT_FOUND);

        return makeResponse(info, request, response);
    }
    
    /**
     * 데이터 중복 입력 오류
     */
    @ExceptionHandler(BizDuplicateException.class)
    public ResponseEntity<?> BizDuplicateException(BizDuplicateException ex, HttpServletRequest request,
            HttpServletResponse response) {
    	log.debug("BizDuplicateException(BizDuplicateException ex, HttpServletRequest request,\n" + 
    			"            HttpServletResponse response)");
        ExceptionInfo info = new ExceptionInfo(ex);

        if (StringUtils.isBlank(info.getUserMessage())) {
            info.setUserMessage(messageSource.getMessage("nglfm.common.exception.duplication",null,Locale.KOREA));
        }
        info.setHttpStatus(HttpStatus.BAD_REQUEST);

        return makeResponse(info, request, response);
    }
    
    
    /**
     * Data Access (DataAccessException)에 대한 핸들러
     */
    @ExceptionHandler(DataAccessException.class)
    public ResponseEntity<?> dataAccessExceptionHandler(DataAccessException ex, HttpServletRequest request,
            HttpServletResponse response) {
    	log.debug("dataAccessExceptionHandler(DataAccessException ex, HttpServletRequest request,\n" + 
    			"            HttpServletResponse response)");
        ExceptionInfo info = new ExceptionInfo(ex);

        if (StringUtils.isBlank(info.getUserMessage())) {
            info.setUserMessage(messageSource.getMessage("nglfm.common.exception.biz",null,Locale.KOREA));
        }
        info.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);

        return makeResponse(info, request, response);
    }
    
    /**
     * EgovBizException Access (DataAccessException)에 대한 핸들러
     */
    @ExceptionHandler(EgovBizException.class)
    public ResponseEntity<?> egovBizExceptionHandler(EgovBizException ex, HttpServletRequest request,
            HttpServletResponse response) {
    	log.debug("egovBizExceptionHandler(EgovBizException ex, HttpServletRequest request,\n" + 
    			"            HttpServletResponse response)");
        ExceptionInfo info = new ExceptionInfo(ex);

        if (StringUtils.isBlank(info.getUserMessage())) {
            info.setUserMessage(messageSource.getMessage("nglfm.common.exception.biz",null,Locale.KOREA));
        }
        info.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);

        return makeResponse(info, request, response);
    }
    
    /**
     * EgovBizException Access (DataAccessException)에 대한 핸들러
     */
    @ExceptionHandler(EgovXssException.class)
    public ResponseEntity<?> egovXssExceptionHandler(EgovXssException ex, HttpServletRequest request,
            HttpServletResponse response) {
    	log.debug("egovXssExceptionHandler(EgovXssException ex, HttpServletRequest request,\n" + 
    			"            HttpServletResponse response)");
        ExceptionInfo info = new ExceptionInfo(ex);

        if (StringUtils.isBlank(info.getUserMessage())) {
            info.setUserMessage(messageSource.getMessage("nglfm.common.exception.unauthorized",null,Locale.KOREA));
        }
        info.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);

        return makeResponse(info, request, response);
    }
    
    /**
     * Validation Error (ValidationException, MethodArgumentNotValidException,
     * BindException) 에 대한 핸들러.
     */
    @ExceptionHandler({ ValidationException.class, 
                        MethodArgumentNotValidException.class, 
                        BindException.class,
//                        MalformedJsonException.class,
//                        HttpMessageNotReadableException.class,
//                        JsonSyntaxException.class,
//                        MalformedJsonException.class,
                        NoSuchMessageException.class,
                        UnexpectedTypeException.class,
                        HttpSessionRequiredException.class})
    public Object validationHandle(Exception ex, HttpServletRequest request, HttpServletResponse response) {

        ExceptionInfo info = new ExceptionInfo(ex);
        
        if (StringUtils.isBlank(info.getUserMessage())) {
            info.setUserMessage(messageSource.getMessage("nglfm.common.exception.validation",null,Locale.KOREA));
        }
        info.setHttpStatus(HttpStatus.BAD_REQUEST);

        return makeResponse(info, request, response);
    }

    /**
     * Unauthorized (UnauthorizedException) 에 대한 핸들러.
     */
    @ExceptionHandler(UnauthorizedException.class)
    public Object unauthorizedHandle(UnauthorizedException ex, HttpServletRequest request,
            HttpServletResponse response) {

        ExceptionInfo info = new ExceptionInfo(ex);

        if (StringUtils.isBlank(info.getUserMessage())) {
            info.setUserMessage(messageSource.getMessage("nglfm.common.exception.unauthorized",null,Locale.KOREA));
        }
        info.setHttpStatus(HttpStatus.UNAUTHORIZED);

        return makeResponse(info, request, response);
    }

    /**
     * Forbidden (ForbiddenException) 에 대한 핸들러.
     */
    @ExceptionHandler(ForbiddenException.class)
    public Object forbiddenHandle(ForbiddenException ex, HttpServletRequest request, HttpServletResponse response) {

        ExceptionInfo info = new ExceptionInfo(ex);

        if (StringUtils.isBlank(info.getUserMessage())) {
            info.setUserMessage(messageSource.getMessage("nglfm.common.exception.forbidden",null,Locale.KOREA));
        }
        info.setHttpStatus(HttpStatus.FORBIDDEN);

        return makeResponse(info, request, response);
    }

    /**
     * Business Error (BizException) 에 대한 핸들러.
     */
    @ExceptionHandler(BizException.class)
    public Object bizHandle(BizException ex, HttpServletRequest request, HttpServletResponse response) {
    	log.debug(">> BizException");
        ExceptionInfo info = new ExceptionInfo(ex);

        if (StringUtils.isBlank(info.getUserMessage())) {
            info.setUserMessage(messageSource.getMessage("nglfm.common.exception.biz",null,Locale.KOREA)); 
        }

        // 강제 ok설정이면, status code 는 ok로.
        log.debug("info.isForcesOK() " + info.isForcesOK());
        if (info.isForcesOK()) {
            info.setHttpStatus(HttpStatus.OK);
        } else {
            info.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return makeResponse(info, request, response);
    }
    
    /**
     * Interface Error (InterfaceException) 에 대한 핸들러.
     */
    @ExceptionHandler(InterfaceException.class)
    public Object interfaceHandle(InterfaceException ex, HttpServletRequest request,
            HttpServletResponse response) {

        ExceptionInfo info = new ExceptionInfo(ex);

        if (StringUtils.isBlank(info.getUserMessage())) {
            info.setUserMessage(messageSource.getMessage("nglfm.common.exception.interface",null,Locale.KOREA));
        }
        info.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);

        return makeResponse(info, request, response);
    }    

    /**
     * BaseException 에 대한 핸들러. 정상적이라면 BaseException 타입이 throw되서는 안됨.
     */
    @ExceptionHandler(BaseException.class)
    public Object baseExceptionHandle(Exception ex, HttpServletRequest request, HttpServletResponse response) {

        ExceptionInfo info = new ExceptionInfo(ex);

        if (StringUtils.isBlank(info.getUserMessage())) {
            info.setUserMessage(messageSource.getMessage("nglfm.common.exception.server",null,Locale.KOREA)); 
        }
        info.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);

        return makeResponse(info, request, response);
    }

    /**
     * Exception / RuntimeException 타입에 대한 핸들러.
     */
    @ExceptionHandler({ Exception.class, RuntimeException.class,SocketTimeoutException.class })
    public Object exceptionHandle(Exception ex, HttpServletRequest request, HttpServletResponse response) {
        ExceptionInfo info = new ExceptionInfo(ex);

        info.setUserMessage(messageSource.getMessage("nglfm.common.exception.server",null,Locale.KOREA)); 
        info.setSystemMessage(ex.getMessage());
        info.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);

        return makeResponse(info, request, response);
    }
    
   
    /**
     * response를 위한 객체 생성.
     */
    private ResponseEntity<?> makeResponse(ExceptionInfo info, HttpServletRequest request, HttpServletResponse response) {
/*        log.debug("\n" +
                        "{}" +
                        " - userMessage: {}\n" +
                        " - systemMessage: {}\n" +
                        " - httpStatus: {}\n" +
                        " - code: {}\n");
*/
        
        log.debug("\n" +
        		ExceptionUtils.getStackTrace(info.getE()) +
                " - userMessage: "+info.getUserMessage()+"\n" +
                " - systemMessage: "+info.getSystemMessage()+"\n" +
                " - httpStatus: "+info.getHttpStatus()+ "\n" +
                " - code: "+info.getCode()+"\n" );
        
        
        response.setStatus(info.getHttpStatus().value());
        if(info.getCode() ==null) {
        	info.setCode(info.getHttpStatus().value()+"");
        }
         
        
        RestResponse<Object> restResponse = new RestResponse<>().userMessage(info.userMessage).systemMessage(info.getSystemMessage()).resultCode(info.getCode()).httpStatusCode(info.getHttpStatus()+"");
        return new ResponseEntity<RestResponse<Object>>(restResponse, info.getHttpStatus());
    }

    @Getter
    @Setter
    private class ExceptionInfo {
        private Throwable e;
        private Throwable cause;
        private String userMessage;
        private String systemMessage;
        private boolean forcesOK = false;
        private String code;
        private HttpStatus httpStatus;

        public ExceptionInfo(Throwable e) {
            this.e = e;
            this.cause = e.getCause();
            if (e instanceof BaseException) {
                BaseException be = (BaseException) e;
                this.userMessage = be.getUserMessage();
                this.systemMessage = be.getSystemMessage();
                this.code = be.getCode();
            }
            // @validator에서 뱉는 Exception
            else if (e instanceof MethodArgumentNotValidException) {
                Pair<String, String> msg = setValidationError(((MethodArgumentNotValidException) e).getBindingResult());
                this.userMessage = msg.getFirst();
                this.systemMessage = msg.getSecond();
            }
            // @validator에서 뱉는 Exception
            else if (e instanceof BindException) {
                Pair<String, String> msg = setValidationError(((BindException) e).getBindingResult());
                this.userMessage = msg.getFirst();
                this.systemMessage = msg.getSecond();
            }

            if (e instanceof BizException) {
                this.forcesOK = ((BizException) e).isForcesOK();
            }
            if (cause instanceof BaseException) {
                BaseException be = (BaseException) cause;
                this.userMessage = be.getUserMessage();
                this.systemMessage = be.getSystemMessage();
                this.code = be.getCode();
            }
            if (cause instanceof BizException) {
                this.forcesOK = ((BizException) cause).isForcesOK();
            }

        }

        private Pair<String, String> setValidationError(BindingResult br) {
            
            FieldError fe = br.getFieldError();
            String errorDefaultMessage = null;
            String errorAttribute = null;
            if(fe != null) {
                errorDefaultMessage = fe.getDefaultMessage();
                errorAttribute = fe.getCodes()[0];
            }else {
                ObjectError oe = br.getGlobalError();
                errorDefaultMessage = oe.getDefaultMessage();
                errorAttribute = oe.getCode();
            }

            String key = errorDefaultMessage;
            Object[] args = null;

            if (StringUtils.indexOf(key, ',') > -1) {
                String[] errorMessageArr = key.split(",");
                key = errorMessageArr[0].trim();
                args = new Object[errorMessageArr.length - 1];
                System.arraycopy(errorMessageArr, 1, args, 0, errorMessageArr.length - 1);
            }
            
            log.debug("[KEY]"+key);
            log.debug("[ARGS]"+args);
            String errorMessage="";
            if(args ==null) {
            	errorMessage=key;
            }else if(key ==null && args !=null) {
            	errorMessage=key;
            }else {
            	errorMessage = messageSource.getMessage(key, args,Locale.KOREA);
            }
            
            if(errorMessage == null) {
                errorMessage = errorDefaultMessage; 
            }

            if (StringUtils.lastIndexOf(errorAttribute, '.') > -1) {
//                errorMessage = "[" + errorAttribute.substring(StringUtils.lastIndexOf(errorAttribute, '.') + 1) + "] " + errorMessage;
            	errorMessage =  errorAttribute.substring(StringUtils.lastIndexOf(errorAttribute, '.') + 1) + "," + errorMessage;
            }

            return Pair.of(errorMessage, errorAttribute);
        }        
    }

}
