
package org.egovframe.web.cmmn.support.integration.client.provider.client;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Iterator;

import org.egovframe.web.cmmn.exception.InterfaceException;
import org.egovframe.web.cmmn.support.integration.client.provider.type.MethodType;
import org.egovframe.web.cmmn.support.integration.client.service.RequestChannelParam;
import org.egovframe.web.cmmn.support.utils.connect.ConvertAgentUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequest;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.RequestCallback;
import org.springframework.web.client.ResponseExtractor;
import org.springframework.web.client.RestTemplate;

import lombok.extern.slf4j.Slf4j;
/**
 * 
 * <pre>
 * @Description: 
 *   - 공통 API 외부 연계
 *   - API 연계가 완료되면 String 형태의 Object로 데이터를 받음
 * <pre>
 *
 * @author  : kim kyoung ju
 * @Date    : 2021.05.26
 * @version : 1.0.0
 */
@Slf4j
public class ChannelServiceProvider implements MethodType{ 
	
	@Autowired
	private ConvertAgentUtil convertAgentUtil;
    /**
     * 
     * <pre>
     * @Description: 
     *  - 인터페이스 연계 구현 함수
     *  - Spring restTemplate의 Execute 메소드를 재정의 해서 사용  
     * </pre>
     *
     * @Method     : send
     * @author     : kim kyoung ju
     * @Date       : 2021.05.26
     *
     * @param providerURL
     * @param header
     * @param body
     * @param method
     * @param restTemplate
     * @return
     * @throws Exception
     */
    public Object send(RequestChannelParam param, RestTemplate restTemplate) throws Exception {
		log.info("---------------------------------");
		log.info("요청        서버 :"+param.getRequestUrl());
		if(param.getHeaders() !=null)log.info("요청 header:"+param.getHeaders().toString());
		else			 log.info("요청 header:");
		log.info("요청 METHOD TYPE:"+param.getMethod());
	
		if(GET.equalsIgnoreCase(param.getMethod()) || POST.equalsIgnoreCase(param.getMethod())||PUT.equalsIgnoreCase(param.getMethod())||DELETE.equalsIgnoreCase(param.getMethod())||PATCH.equals(param.getMethod()) )  {
			try{
				
			   Object responseData=restTemplate.execute(   param.getRequestUrl(), 
															HttpExMethod.getMethod(param.getMethod()), 
															new AsyncRequestCallBack(param) ,
															new PayloadToStringRestResponseExtractor(),String.class);
			   
				/** Response 데이터가 없을 경우 **/
				if(responseData==null){ 
					log.error("데이터가 존재하지 않습니다.");
					throw InterfaceException
								.withSystemMessage("데이터가 존재하지 않습니다.")
								.withUserMessage("데이터가 존재하지 않습니다.")
								.withForcesOK(true)
								.withCode("404")
								.build();
				}
				return responseData;
			}catch(Exception ex){
				throw InterfaceException
							.withSystemMessage(ex.getMessage())
							.withUserMessage("오류가 발생 했습니다.")
							.withCause(ex)
							.build();
			}
		}else{
			throw InterfaceException
					.withUserMessage("Method Type이 존재하지 않습니다.")
					.withCode("400")
					.build();
		}
		
	}
    /**
     * 
     * <pre>
     * @Description: Method Type 정의 
     * <pre>
     *
     * @author  : kim kyoung ju
     * @Date    : 2021.05.26
     * @version : 1.0.0
     */
	public final static class HttpExMethod {
		private HttpExMethod(){}
		public static HttpMethod getMethod(String method) throws Exception{
			if(POST.equalsIgnoreCase(method)){
				return HttpMethod.POST;
			}else if(GET.equalsIgnoreCase(method)){
				return HttpMethod.GET;
			}else if(PUT.equalsIgnoreCase(method)){
				return HttpMethod.PUT;
			}else if(DELETE.equalsIgnoreCase(method)){
				return HttpMethod.DELETE;
			}else if(PATCH.equalsIgnoreCase(method)){
				return HttpMethod.PATCH;	
			}
		else{
			throw InterfaceException
						.withUserMessage("Method Type이 존재하지 않습니다.")
						.withCode("400")
						.build();
			}
		}
	}
	/**
	 * 
	 * <pre>
	 * @Description: 
     *   - Spring Execute  재구현 클래스
     *   - Async 방식으로 Client 연계 
	 * <pre>
	 *
	 * @author  : kim kyoung ju
	 * @Date    : 2021.05.26
	 * @version : 1.0.0
	 */
	protected class AsyncRequestCallBack implements RequestCallback {
		private RequestChannelParam param;
		
		public AsyncRequestCallBack(RequestChannelParam param){
			this.param=param;
		}
		
        public void doWithRequest(ClientHttpRequest clientHttpRequest){
            try{
            	HttpHeaders headers = clientHttpRequest.getHeaders();
	            
            	log.info("doWithRequest.getURI()===>"+clientHttpRequest.getURI());
	            /** Header 세팅 **/
	        	if(param.getHeaders() !=null){
	    			Iterator iter=param.getHeaders().keySet().iterator();
	    			while(iter.hasNext()){
	    				String headerType=(String)iter.next();
	    				String headerValue=param.getHeaders().get(headerType);
	    				headers.add(headerType, headerValue);
	    			}
	    		}
	        	/** Body 세팅 **/
	    		if(param.getBody() !=null){
	    		    byte requestByte[]=param.getBody().getBytes("UTF-8");
    		        clientHttpRequest.getBody().write(requestByte, 0, requestByte.length);
		    	}
            }catch(Exception e){
            	throw InterfaceException
					.withSystemMessage(e.getMessage())
					.withCause(e)
					.build();
            }
        }
    } 
	/**
	 * 
	 * <pre>
	 * @Description: client 연계결과 반환
	 * <pre>
	 *
	 * @author  : kim kyoung ju
	 * @Date    : 2021.05.26
	 * @version : 1.0.0
	 */
	protected class PayloadToStringRestResponseExtractor implements ResponseExtractor<Object> {
    	private Object result;
    	
    	
    	
    	public Object getResult() {
			return result;
		}

    	public void setResult(Object result) {
			this.result = result;
		}

		/**
    	 *  - 결과를 받아 처리하는 Overriding 메소드 
    	 */
        public Object extractData(ClientHttpResponse clientHttpResponse){
        
        	try{
	        	
	        	InputStream is=clientHttpResponse.getBody();
	        	String message=clientHttpResponse.getStatusText();
	        	HttpStatus code =clientHttpResponse.getStatusCode();
	        	
	        	HttpHeaders header=clientHttpResponse.getHeaders();
	        	MediaType contentType=header.getContentType();
	        	String mediaType=contentType.getType();
	        	
	        	log.debug("[요청 결과           ]"+code.value());
	        	log.debug("[요청 결과 메세지  ]"+message);
	        	
	        	String sourceData="";
	        	
	        	byte[] b = new byte[8192];
	        	int n;
 
	        	try (BufferedInputStream bis = new BufferedInputStream(is);
	        	       	ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
		            while((n = bis.read(b)) != -1) {
		            	bos.write(b, 0, n);
			         }
		            	sourceData = bos.toString("UTF-8");
	        	 }
	            	
//	             log.debug("요청 결과 데이터 :" + sourceData);
//	             //////////////////////요청 데이터 결과를 hashmap 형태로 반환 //////////////////////////
//	        	 if(mediaType ==null)mediaType="";
//	        	 if(mediaType.toLowerCase().contains("xml")) {
////	                KhneInterfaceAgent agent=new KhneInterfaceAgent();
////	                String jsonData=agent.xmlToJson(sourceData);
////	                
////	                HashMap<String,Object> dataMap=new HashMap<String,Object>();
////                       JsonParserUtil utils=new JsonParserUtil(dataMap);
////                       utils.jsonUnmashall(jsonData);
////                       result=utils.getDataMap();
//                }else { 
//            	      HashMap<String,Object> dataMap=new HashMap<String,Object>();
//            	        JsonParserUtil utils=new JsonParserUtil(dataMap);
//            	        utils.jsonUnmashall(sourceData);
//            	        result=utils.getDataMap();
//                } 
//	            	//////////////////////요청 데이터 결과를 hashmap 형태로 반환 //////////////////////////
	            	
	        	result=sourceData;
	       }catch(Exception e){
	    	   throw InterfaceException
					.withSystemMessage(e.getMessage())
					.withCause(e)
					.build();
			}
        	return this.getResult();
        }
    }
    
  }
