package org.egovframe.web.cmmn.aop.vo;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
/**
 * RESTful 응답 format 공통 class
 * @author kim
 *
 * @param <T>
 */
@Getter
@Setter
public class RestResponseData<T> implements Serializable {
    private static final long serialVersionUID = -6618206850210257861L;
    
    private List<T> list;
    private String resultCode;
//    private String message;
    private String userMessage;
    private String systemMessage;
    private String httpStatusCode;
}
