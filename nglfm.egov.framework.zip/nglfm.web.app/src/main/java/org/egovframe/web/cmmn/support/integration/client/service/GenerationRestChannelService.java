
package org.egovframe.web.cmmn.support.integration.client.service;

import org.egovframe.web.cmmn.adapter.IChannelService;
import org.egovframe.web.cmmn.support.integration.client.provider.client.ChannelServiceProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@Service("generationRestChannelService")
public class GenerationRestChannelService extends SSLConnectionEnable implements IChannelService{

	public GenerationRestChannelService(){}

	@Autowired
	private RestTemplate restTemplate;
	@Autowired
	private ChannelServiceProvider channelServiceProvider;
	
	@Override
	public Object execute(RequestChannelParam param) throws Exception {
	    if(GenerationRestChannelService.isHttpsProtocol(param.getRequestUrl()))enableSSL(restTemplate);
		
	    return channelServiceProvider.send(param, restTemplate);
		
	}
}
