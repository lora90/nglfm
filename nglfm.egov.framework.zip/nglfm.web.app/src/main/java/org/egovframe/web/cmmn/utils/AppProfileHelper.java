package org.egovframe.web.cmmn.utils;
import org.egovframe.web.cmmn.exception.NotFoundException;

import lombok.extern.slf4j.Slf4j;
/**
 * 
 * TODO : 서버 환경 별 프로파일 분리.
 * @author 김경주
 *
 */
@Slf4j
public class AppProfileHelper {

	public static boolean isProfile(String mode) {
		String profiles = System.getProperty("spring.profiles.active");

		if (profiles.contains(mode)) {
			return true;
		} else {
			return false;
		}
	} 

	public static String getActiveMode() {
		String profiles = System.getProperty("spring.profiles.active");
		log.debug(">> profiles+"+profiles);
		if (profiles.contains("default")) {
			return "default";
		}else if(profiles.contains("dev")) {
			return "dev";
		}else if(profiles.contains("prod")) {
			return "prod";
		} else {
			throw NotFoundException.withUserMessage("서버 모드가 존재하지 않습니다.").withCode("404").build();
		}
	}
}