package org.egovframe.web.config.spring.db.aop;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.aop.Advisor;
import org.springframework.aop.aspectj.AspectJExpressionPointcut;
import org.springframework.aop.support.DefaultPointcutAdvisor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.interceptor.DefaultTransactionAttribute;
import org.springframework.transaction.interceptor.RollbackRuleAttribute;
import org.springframework.transaction.interceptor.RuleBasedTransactionAttribute;
import org.springframework.transaction.interceptor.TransactionInterceptor;

import lombok.extern.slf4j.Slf4j;

@Configuration
@Slf4j
public class ContextMariaTransaction {
	@Autowired
	DataSource mariaDataSource;
	
	@Bean
	public PlatformTransactionManager txMariaManager() throws Exception {
		return new DataSourceTransactionManager(mariaDataSource);
	}

	@Bean
	public TransactionInterceptor transactionMariaAdvice() throws Exception {
		TransactionInterceptor txAdvice = new TransactionInterceptor();
		Properties txAttributes = new Properties();
		List<RollbackRuleAttribute> rollbackRules = new ArrayList<RollbackRuleAttribute>();
		rollbackRules.add(new RollbackRuleAttribute(Exception.class));

		/** If need to add additionall exceptio, add here **/
		DefaultTransactionAttribute readOnlyAttribute = new DefaultTransactionAttribute(TransactionDefinition.PROPAGATION_REQUIRED);
		readOnlyAttribute.setReadOnly(true);
		readOnlyAttribute.setTimeout(3);
		RuleBasedTransactionAttribute writeAttribute = new RuleBasedTransactionAttribute(TransactionDefinition.PROPAGATION_REQUIRED, rollbackRules);
		writeAttribute.setTimeout(3);

		String readOnlyTransactionAttributesDefinition = readOnlyAttribute.toString();
		String writeTransactionAttributesDefinition = writeAttribute.toString();

		log.debug("Read Only Attributes :: {}", readOnlyTransactionAttributesDefinition);
		log.debug("Write Attributes :: {}", writeTransactionAttributesDefinition);

		//read-only
//		txAttributes.setProperty("validator*", readOnlyTransactionAttributesDefinition);
//		txAttributes.setProperty("check*", readOnlyTransactionAttributesDefinition);
//		txAttributes.setProperty("search*", readOnlyTransactionAttributesDefinition);
//		txAttributes.setProperty("contract*", readOnlyTransactionAttributesDefinition); //연계
//		txAttributes.setProperty("action*", readOnlyTransactionAttributesDefinition);
//		txAttributes.setProperty("read*", readOnlyTransactionAttributesDefinition); //파일읽기
//		txAttributes.setProperty("write*", readOnlyTransactionAttributesDefinition); //파일쓰기
//		txAttributes.setProperty("select*", readOnlyTransactionAttributesDefinition); 
//		txAttributes.setProperty("get*", readOnlyTransactionAttributesDefinition); 

		//Write rollback-rule
//		txAttributes.setProperty("insert*", writeTransactionAttributesDefinition);
//		txAttributes.setProperty("update*", writeTransactionAttributesDefinition);
//		txAttributes.setProperty("create*", writeTransactionAttributesDefinition);
//		txAttributes.setProperty("delete*", writeTransactionAttributesDefinition);
//		txAttributes.setProperty("merge*", writeTransactionAttributesDefinition);
		
		txAttributes.setProperty("*", writeTransactionAttributesDefinition);
		
		txAdvice.setTransactionAttributes(txAttributes);
		txAdvice.setTransactionManager(txMariaManager());
		return txAdvice;
	}

	@Bean
	public Advisor transactionmariaAdviceAdvisor() throws Exception {
		AspectJExpressionPointcut pointcut = new AspectJExpressionPointcut();
		pointcut.setExpression("execution(* *..*Impl.*(..))");
		return new DefaultPointcutAdvisor(pointcut, transactionMariaAdvice());
	}
	
	
	
	
}
