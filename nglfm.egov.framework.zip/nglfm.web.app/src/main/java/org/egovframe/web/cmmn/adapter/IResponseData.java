package org.egovframe.web.cmmn.adapter;

import javax.servlet.http.HttpServletRequest;

public interface IResponseData {
	public String getType(HttpServletRequest request) throws Exception;
}
