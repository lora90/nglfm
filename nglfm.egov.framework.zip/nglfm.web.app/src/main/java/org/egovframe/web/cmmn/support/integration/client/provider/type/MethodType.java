
package org.egovframe.web.cmmn.support.integration.client.provider.type;

public interface MethodType {
	
	/** The GET. */
	public final String GET    = "GET";
	
	/** The POST. */
	public final String POST   = "POST";
	
	/** The PUT. */
	public final String PUT    = "PUT";
	
	/** The DELETE. */
	public final String DELETE = "DELETE";
	
	public final String PATCH = "PATCH";
	
}
