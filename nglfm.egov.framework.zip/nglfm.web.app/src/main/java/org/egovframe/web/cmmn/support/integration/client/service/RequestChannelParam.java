package org.egovframe.web.cmmn.support.integration.client.service;

import java.util.Map;

import org.egovframe.web.cmmn.support.integration.client.provider.type.ServiceType;


public class RequestChannelParam{
	private Map<String,String> headers;
	private String method;
	private String requestUrl;
	private String callService;
	private String body;
	
	public Map<String, String> getHeaders() {
		return headers;
	}
	public void setHeaders(Map<String, String> headers) {
		this.headers = headers;
	}
	public String getMethod() {
		return method;
	}
	public void setMethod(String method) {
		this.method = method;
	}
	public String getRequestUrl() {
		return requestUrl;
	}
	public void setRequestUrl(String requestUrl) {
		this.requestUrl = requestUrl;
	}
	public String getCallService() {
		return callService;
	}
	public void setCallService(ServiceType type) {
		
		this.callService = type.getValue();;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	
	
	
}
