package org.egovframe.web.config.spring;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import({ ContextAspect.class, ContextCommon.class,ContextProperties.class})
public class RootContext {

}
