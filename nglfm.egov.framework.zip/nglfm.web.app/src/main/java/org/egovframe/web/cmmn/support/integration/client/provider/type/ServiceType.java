package org.egovframe.web.cmmn.support.integration.client.provider.type;

public enum ServiceType {
	LAGUCY("LAGUCY"),BATCH("BATCH"),REST("REST");
	
	String value;
	
    private ServiceType(String value){
        this.value = value;
    }
    public String getValue(){
        return value;
    }
}
