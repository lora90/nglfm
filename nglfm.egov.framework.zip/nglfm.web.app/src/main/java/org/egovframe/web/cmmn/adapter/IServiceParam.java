package org.egovframe.web.cmmn.adapter;

import java.util.Map;

public interface IServiceParam {
	public Map<String,String> setHeader(Map<String,String> headers);
	public String method(String type);
	public String requestUrl(String url);
}
