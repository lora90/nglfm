package org.egovframe.web.config.spring;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.egovframe.rte.fdl.cmmn.exception.FdlException;
import org.egovframe.rte.fdl.property.impl.EgovPropertyServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ResourceLoader;

@Configuration
public class ContextProperties {
	
	@Autowired
    ResourceLoader resourceLoader;

	@Bean(name="propertiesService",destroyMethod="destroy")
	public EgovPropertyServiceImpl propertiesService() throws FdlException{
		Map<String, String> properties = new HashMap<String, String>();
		properties.put("pageUnit", "10");
		properties.put("pageSize", "10");
				
		Set<Map<String,Object>> extFileName=new HashSet<>();
		Map<String,Object> element=new HashMap<>();
		
		element.put("encoding", "EUC-KR");
		element.put("filename", "classpath*:/properties/*.properties");
		
		extFileName.add(element);
		
		EgovPropertyServiceImpl egovPropertyServiceImpl = new EgovPropertyServiceImpl();
		egovPropertyServiceImpl.setProperties(properties);
		egovPropertyServiceImpl.setExtFileName(extFileName);
		
		return egovPropertyServiceImpl;
		
	}
}
