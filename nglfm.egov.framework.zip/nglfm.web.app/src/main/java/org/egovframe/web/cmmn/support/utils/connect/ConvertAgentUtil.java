package org.egovframe.web.cmmn.support.utils.connect;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.json.XML;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.json.XML;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ConvertAgentUtil {
    
//	public String objectToXML(Object obj) throws IOException {
//        ObjectMapper mapper = new XmlMapper();
//        String xml = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(obj);
//
//         log.debug("\n" + mapper.writerWithDefaultPrettyPrinter().writeValueAsString(obj));
//        
//        return xml;
//    }
	
	
	
    public String xmlToJson(String xml) {
        org.json.JSONObject json = XML.toJSONObject(xml);
        return  json.toString();
    }
    
    public String objectToXML(Object obj) throws IOException {

    	try {
    		ObjectMapper mapper = new XmlMapper();
    		String xml = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(obj);
    		return xml;
    	}catch(Exception ext) {
    		ext.printStackTrace();
    		return null;
    	}
    	
    	
    }
    
    public String objectToXml(Object obj) throws JsonProcessingException {
        ObjectMapper mapper = new XmlMapper();
        return mapper.writeValueAsString(obj);
    }
    
    public String objectToJson(Object obj) {
		String json="";
		try {
			Gson gson = new GsonBuilder().serializeNulls().setPrettyPrinting().create();
			json=gson.toJson(obj);
		} catch(Exception e) {
			log.error(e.getMessage(),e);
		}
		return json.trim(); 
	}
    
    public Object xmlToObject(String xml,Class<?> cls) {
    	ObjectMapper mapper=new XmlMapper();
    	
    	try {
			return mapper.readValue(xml, cls);
		} catch (JsonProcessingException e) {
			
			return null;
		}
    }
    
    @SuppressWarnings("unchecked")
	public String jsonToXml(String json) {
        String xml="";
        try {
            ObjectMapper mapper = new ObjectMapper();
            Map<Object,Object> map = mapper.readValue(json, Map.class);
            XmlMapper xmlMapper = new XmlMapper();
            xml = xmlMapper.writeValueAsString(map);
        }catch(Exception ext) {
            ext.printStackTrace();
        }
        //ObjectMapper에서 HashMap 형태로 json->xml을 convert 하기 때문에 'LinkedHashMap' 테그가 생김...^^; 제거 해버림..
        return xml.replaceAll("<LinkedHashMap>", "").replaceAll("</LinkedHashMap>", "");
    }
    
    
    public Map<String, Object> jsonFromMap(String json){
    	Map<String, Object> retMap = new Gson().fromJson(
    		    json, new TypeToken<HashMap<String, Object>>() {}.getType()
    		);
    	
    	return retMap;
    }
}
