package org.egovframe.web.config.servlet;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.egovframe.egov.page.EgovImgPaginationRenderer;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.DefaultPaginationManager;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationRenderer;
import org.egovframe.web.cmmn.context.ApplicationContextProvider;
import org.egovframe.web.cmmn.support.integration.client.provider.client.ChannelServiceProvider;
import org.egovframe.web.cmmn.support.integration.client.service.LinkChannelServiceAdapter;
import org.egovframe.web.cmmn.support.utils.connect.ChannelServiceHelper;
import org.egovframe.web.cmmn.support.utils.connect.ConvertAgentUtil;
import org.egovframe.web.filter.RequestAndResponseLoggingFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;
import org.springframework.web.servlet.view.JstlView;
import org.springframework.web.servlet.view.UrlBasedViewResolver;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;

@Configuration
public class ServletContext implements WebMvcConfigurer {



	@Bean
	public SessionLocaleResolver localeResolver() {
		SessionLocaleResolver sessionLocaleResolver = new SessionLocaleResolver();
		return sessionLocaleResolver;
	}

	/*
	 * // 쿠키를 이용한 Locale 이용시 이 부분을 주석처리를 풀어서 사용하고 위에 있는 SessionLocaleResolver 클래스를
	 * 사용하는 // @Bean 메소드는 주석처리 한다
	 * 
	 * @Bean public CookieLocaleResolver localeResolver(){ CookieLocaleResolver
	 * cookieLocaleResolver = new CookieLocaleResolver(); return
	 * cookieLocaleResolver; }
	 */

	@Bean
	public LocaleChangeInterceptor localeChangeInterceptor() {
		LocaleChangeInterceptor localeChangeInterceptor = new LocaleChangeInterceptor();
		localeChangeInterceptor.setParamName("language");
		return localeChangeInterceptor;
	}

	@Bean
	public EgovImgPaginationRenderer imageRenderer() {
		EgovImgPaginationRenderer egovImgPaginationRenderer = new EgovImgPaginationRenderer();
		return egovImgPaginationRenderer;
	}

	@Bean
	public DefaultPaginationManager paginationManager(EgovImgPaginationRenderer imageRenderer) {
		DefaultPaginationManager defaultPaginationManager = new DefaultPaginationManager();
		Map<String, PaginationRenderer> rendererType = new HashMap<String, PaginationRenderer>();
		rendererType.put("image", imageRenderer);
		defaultPaginationManager.setRendererType(rendererType);
		return defaultPaginationManager;
	}
	
	@Bean
	public FilterRegistrationBean<RequestAndResponseLoggingFilter> getFilterRegistrationBean() {
		FilterRegistrationBean<RequestAndResponseLoggingFilter> registrationBean = new FilterRegistrationBean<RequestAndResponseLoggingFilter>(new RequestAndResponseLoggingFilter());
		registrationBean.setOrder(Integer.MIN_VALUE);
		registrationBean.setUrlPatterns(Arrays.asList("/*"));
		return registrationBean;
	}
	
	@Bean
	MappingJackson2JsonView jsonView() {
		return new MappingJackson2JsonView();
	}
	
	
	@Override 
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(localeChangeInterceptor());
		
	}
	
	
	@Bean(name = "restTemplate")
    public RestTemplate getCustomRestTemplate(){
        HttpComponentsClientHttpRequestFactory httpRequestFactory = new HttpComponentsClientHttpRequestFactory();
        httpRequestFactory.setConnectTimeout(2000);
        httpRequestFactory.setReadTimeout(3000);
        HttpClient httpClient = HttpClientBuilder.create()
                .setMaxConnTotal(200)
                .setMaxConnPerRoute(20)
                .build();
        httpRequestFactory.setHttpClient(httpClient);
        return new RestTemplate(httpRequestFactory);
    }
	
	@Bean
	public ChannelServiceProvider channelServiceProvider() {
		return new ChannelServiceProvider();
	}
	
	@Bean
	public LinkChannelServiceAdapter linkChannelServiceAdapter() {
		return new LinkChannelServiceAdapter();
	}
	
	@Bean
	public ConvertAgentUtil convertAgentUtil() {
		return new ConvertAgentUtil();
	}
	
	@Bean
	public ChannelServiceHelper channelServiceHelper() {
		return new ChannelServiceHelper();
	}
	
	@Bean
	public ApplicationContextProvider applicationContextProvider() {
		return new ApplicationContextProvider();
	}
}
