package org.egovframe.web.cmmn.support.utils.connect;

import org.egovframe.web.cmmn.support.integration.client.service.LinkChannelServiceAdapter;
import org.egovframe.web.cmmn.support.integration.client.service.RequestChannelParam;
import org.springframework.beans.factory.annotation.Autowired;

public class ChannelServiceHelper {
	@Autowired
	private LinkChannelServiceAdapter linkChannelServiceAdapter;
	
	public Object connect(RequestChannelParam param) throws Exception{
		
		
		
		return linkChannelServiceAdapter.call(param);
		
	}
}
