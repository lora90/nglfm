package org.egovframe.web.cmmn.exception;

import lombok.Getter;
import lombok.Setter;

public class BizDuplicateException  extends BaseException {
	
		private static final long serialVersionUID = -7424001266836744715L;
		/**
	     * client에게 HTTP STATUS CODE가 200(ok)로 리턴되게 강제하는지의 여부.
	     */
	    @Getter
	    @Setter
	    private boolean forcesOK = false;

	    public BizDuplicateException(String systemMessage, Throwable cause, boolean enableSuppression, boolean writableStackTrace,
	            String userMessage) {
	        super(systemMessage, cause, enableSuppression, writableStackTrace, userMessage);
	    }

	    public static BaseExceptionBuilder withUserMessage(String userMessage) {
	        BaseExceptionBuilder builder = new BaseExceptionBuilder(BizException.class);
	        builder.withUserMessage(userMessage);
	        return builder;
	    }

	    public static BaseExceptionBuilder withUserMessage(String userMessageFormat, Object... objects) {
	        return BizException.withUserMessage(BaseExceptionBuilder.formatMessage(userMessageFormat, objects));
	    }
	    
	    public static BaseExceptionBuilder withUserMessageKey(String userMessageKey) {
	        BaseExceptionBuilder builder = new BaseExceptionBuilder(BizException.class);
	        builder.withUserMessageKey(userMessageKey);
	        return builder;
	    }

	    public static BaseExceptionBuilder withUserMessageKey(String userMessageKey, Object... objects) {
	        BaseExceptionBuilder builder = new BaseExceptionBuilder(BizException.class);
	        builder.withUserMessageKey(userMessageKey, objects);
	        return builder;
	    }

	    public static BaseExceptionBuilder withSystemMessage(String systemMessage) {
	        BaseExceptionBuilder builder = new BaseExceptionBuilder(BizException.class);
	        builder.withSystemMessage(systemMessage);
	        return builder;
	    }

	    public static BaseExceptionBuilder withSystemMessage(String systemMessageFormat, Object... objects) {
	        return BizException.withSystemMessage(BaseExceptionBuilder.formatMessage(systemMessageFormat, objects));
	    }

}
