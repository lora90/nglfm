
package org.egovframe.web.cmmn.support.integration.client.service;

import org.egovframe.web.cmmn.adapter.IChannelService;

import lombok.extern.slf4j.Slf4j;


@Slf4j
public class GenerationLagucyChannelService implements IChannelService{

	public GenerationLagucyChannelService(){}
	
	@Override
	public Object execute(RequestChannelParam param) throws Exception {
		
		log.debug(">> Lagucy called..");
		return null;
	}
	
}
