package org.egovframe.web.cmmn.aop.vo;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
/**
 * RESTful API 응답 공통 
 * @author kim 
 *
 * @param <T>
 */
public class RestResponse<T> implements Serializable {

    /*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    | Private Variables
    |-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    private static final long serialVersionUID = -7857710275656843711L;

    // Data
    @Getter
    private T data;

    @Getter
    private RestResponseHeader header = new RestResponseHeader();

    /*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    | Constructor
    |-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

    /**
     *
     */
    public RestResponse() {
    }

    /**
     *
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public RestResponse(T data) {
        this.data = data;

        if (data instanceof RestResponseData) {
           
            this.data = (T) ((RestResponseData) data).getList();
            this.header.setResultCode(((RestResponseData) data).getResultCode());
            this.header.setUserMessage(((RestResponseData) data).getUserMessage());
            this.header.setSystemMessage(((RestResponseData) data).getSystemMessage());
            this.header.setHttpStatusCode(((RestResponseData) data).getHttpStatusCode());
        }
    }

    /*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    | Getter & Setter Method
    |-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /**
     * useMessage
     */
    public void setUserMessage(String message) {
        this.header.setUserMessage(message);
    }
    
    public void setHttpStatusCode(String httpStatusCode) {
        this.header.setHttpStatusCode(httpStatusCode);;
    }
   
//    public void setMessage(String message) {
//        this.header.setMessage(message);
//    }

    /**
     * systemMessage
     */
    public void setSystemMessage(String systemMessage) {
        this.header.setSystemMessage(systemMessage);
    }

//    /**
//     * code
//     */
//    public void setCode(String code) {
//        this.header.setCode(code);
//    }
    
    public void setResultCode(String resultCode) {
        this.header.setResultCode(resultCode);
    }

    /*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    | Public Method for chaining
    |-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

    public RestResponse<T> systemMessage(String systemMessage) {
        this.setSystemMessage(systemMessage);
        return this;
    }
    
    public RestResponse<T> userMessage(String message) {
        this.setUserMessage(message);
        return this;
    }

    public RestResponse<T> resultCode(String resultCode) {
        this.setResultCode(resultCode);
        return this;
    }
    
    public RestResponse<T> httpStatusCode(String httpStatusCode) {
        this.setHttpStatusCode(httpStatusCode);
        return this;
    }

    /*-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    | Inner Class
    |-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    @Getter
    @Setter
    private class RestResponseHeader implements Serializable {
        private static final long serialVersionUID = 144476231638185217L;

//        private String userMessage = "";
        private String systemMessage = "";
        private String userMessage ="";
        private String resultCode = "";
        private String httpStatusCode="";
        //private int totalCount;
    }
}
