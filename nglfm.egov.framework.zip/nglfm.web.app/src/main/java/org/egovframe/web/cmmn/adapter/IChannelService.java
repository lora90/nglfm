package org.egovframe.web.cmmn.adapter;

import org.egovframe.web.cmmn.support.integration.client.service.RequestChannelParam;

public interface IChannelService {
	public Object execute(RequestChannelParam param) throws Exception;
}
 