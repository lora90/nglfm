package org.egovframe.web.cmmn.support.integration.client.provider.type;

public interface HeaderType {
	public String CONTENT_TYPE="Content-Type";
	public String ACCEPT="Accept";
}
