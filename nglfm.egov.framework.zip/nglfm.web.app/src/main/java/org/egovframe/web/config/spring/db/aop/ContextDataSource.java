package org.egovframe.web.config.spring.db.aop;

import javax.inject.Inject;
import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

@Configuration
@PropertySource("classpath:/properties/db-${spring.profiles.active}.properties")
public class ContextDataSource {
	@Inject
	private  Environment environment;
	
	@Primary
	@Lazy(value = true)
	@Bean(name="mysqlDataSource",destroyMethod="close")
	public DataSource mysqldataSource(){
		if(environment.getProperty("Globals.Server.Mode").equals("default")) {
			if (environment.getProperty("Globals.DbType").contains("mysql")) {
				BasicDataSource basicDataSource = new BasicDataSource();
				basicDataSource.setDriverClassName(environment.getProperty("Globals.mysql.DriverClassName"));
				basicDataSource.setUrl(environment.getProperty("Globals.mysql.Url"));
				basicDataSource.setUsername(environment.getProperty("Globals.mysql.UserName"));
				basicDataSource.setPassword(environment.getProperty("Globals.mysql.Password"));
				return basicDataSource;
			}
		}
		return null;
	}
	
	@Lazy(value = true)
	@Bean(name="mariaDataSource",destroyMethod="close")
	public DataSource mariadataSource(){
		if(environment.getProperty("Globals.Server.Mode").equals("default")) {
			if (environment.getProperty("Globals.DbType").contains("maria")) {
				BasicDataSource basicDataSource = new BasicDataSource();
				basicDataSource.setDriverClassName(environment.getProperty("Globals.maria.DriverClassName"));
				basicDataSource.setUrl(environment.getProperty("Globals.maria.Url"));
				basicDataSource.setUsername(environment.getProperty("Globals.maria.UserName"));
				basicDataSource.setPassword(environment.getProperty("Globals.maria.Password"));
				return basicDataSource;
			}
		}
		return null;
	}
	
//	@Lazy(value = true)
//	@Bean(name="oracleDataSource",destroyMethod="close")
//	public DataSource oracleDataSource(){
//		if(environment.getProperty("Globals.Server.Mode").equals("default")) {
//			if (environment.getProperty("Globals.DbType").contains("oracle")) {
//				BasicDataSource basicDataSource = new BasicDataSource();
//				basicDataSource.setDriverClassName(environment.getProperty("Globals.oracle.DriverClassName"));
//				basicDataSource.setUrl(environment.getProperty("Globals.oracle.Url"));
//				basicDataSource.setUsername(environment.getProperty("Globals.oracle.UserName"));
//				basicDataSource.setPassword(environment.getProperty("Globals.oracle.Password"));
//				return basicDataSource;
//			}	
//		}
//		
//		return null;
//	}
//	
//
//	@Lazy(value = true)
//	@Bean(name="tiberoDataSource",destroyMethod="close")
//	public DataSource tiberoDataSource(){
//		if(environment.getProperty("Globals.Server.Mode").equals("default")) {
//			if (environment.getProperty("Globals.DbType").contains("tibero")) {
//				BasicDataSource basicDataSource = new BasicDataSource();
//				basicDataSource.setDriverClassName(environment.getProperty("Globals.tibero.DriverClassName"));
//				basicDataSource.setUrl(environment.getProperty("Globals.tibero.Url"));
//				basicDataSource.setUsername(environment.getProperty("Globals.tibero.UserName"));
//				basicDataSource.setPassword(environment.getProperty("Globals.tibero.Password"));
//				return basicDataSource;
//			}
//		}
//		return null;
//	}
//			
//	@Bean(name = "hsqldbDataSource", destroyMethod = "close")
//	public DataSource hsqldbDataSource() {
//		if (environment.getProperty("Globals.Server.Mode").equals("default")) {
//			// hsqldb embedded 테스트
//			if (environment.getProperty("Globals.DbType").contains("hsqldb")) {
//				return new EmbeddedDatabaseBuilder().setType(EmbeddedDatabaseType.HSQL).setScriptEncoding("UTF-8")
//						.addScript("").build();
//			}
//		}
//		return null;
//
//	}
	
	
	
	
	/**
	@Bean
	public DataSource dataSource() throws DataSourceLookupFailureException {
		
		JndiDataSourceLookup jdsl = new JndiDataSourceLookup();
		jdsl.setResourceRef(true);
		DataSource dataSource = jdsl.getDataSource("jdbc/oracle");
		return dataSource;
		
	}
	
	@Bean
	public DataSource dataSource() throws NamingException {
		
		JndiTemplate jndiTemplate = new JndiTemplate();
		DataSource dataSource = jndiTemplate.lookup("java:comp/env/jdbc/oracle", DataSource.class);
		return dataSource;
		
	}
	*/
	
}
