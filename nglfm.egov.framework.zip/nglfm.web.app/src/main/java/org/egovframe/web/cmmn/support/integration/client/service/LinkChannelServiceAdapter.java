package org.egovframe.web.cmmn.support.integration.client.service;

import org.egovframe.web.cmmn.adapter.IChannelService;
import org.egovframe.web.cmmn.exception.InterfaceException;
import org.egovframe.web.cmmn.support.integration.client.provider.type.ServiceType;
import org.egovframe.web.cmmn.support.utils.connect.BeanUtils;

public class LinkChannelServiceAdapter {
	
	public Object call(RequestChannelParam param) throws Exception{
		Object result=null;
		if(param !=null) {
			ServiceType serviceType=ServiceType.valueOf(param.getCallService());
			
			switch(serviceType) {
				case  BATCH :{
					IChannelService batchService =(IChannelService) BeanUtils.getBean("generationBatchChannelService");
					result=batchService.execute(param);
				}
				break;
				case REST :{
					IChannelService restService =(IChannelService) BeanUtils.getBean("generationRestChannelService");
					result=restService.execute(param);
				}
				break;
				case LAGUCY : {
					IChannelService regucyService =(IChannelService)BeanUtils.getBean("generationLagucyChannelService");
					result=regucyService.execute(param);
				}
			}
		}else {
			throw InterfaceException.withUserMessage("호출 파라메타가 세팅 되지 않았습니다.").withCode("400").build();
		}
		
		return result;
	}
	
	
	
}
