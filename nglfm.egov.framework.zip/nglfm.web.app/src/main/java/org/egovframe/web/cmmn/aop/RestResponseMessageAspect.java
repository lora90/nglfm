
package org.egovframe.web.cmmn.aop;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.egovframe.web.cmmn.aop.vo.RestResponse;
import org.egovframe.web.cmmn.exception.BizDuplicateException;
import org.egovframe.web.cmmn.exception.BizException;
import org.egovframe.web.cmmn.exception.NotFoundException;
import org.egovframe.web.cmmn.exception.UnauthorizedException;
import org.egovframe.web.cmmn.exception.ValidationException;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import lombok.extern.slf4j.Slf4j;

@Aspect
@ControllerAdvice(basePackages = {"org.egovframe","kr","org","com","gov","net","edu" }, annotations = {RestController.class,Controller.class})
@Slf4j
public class RestResponseMessageAspect {
	/**
	 * * - 결과 데이터를 공통 메세지 포맷으로 변환. 
	 * - ResponseEntity(HTTP 상태코드 + 공통 메세지 포맷) 리턴.
	 * - Header Type : application/json 만 공통으로 메세지 전달한다.
	 * 
	 * <응답 예시> HTTP RESPONSE STATUS CODE : 200 RESPONSE BODY 
	 * { 
	 *  "header" :{
	 *   .. 
	 *  },  
	 *  "data": {
	 *   ...
	 *      
	 *  } 
	 * }
	 */
	@Around("execution(* *..*Controller.*(..)) && !execution(* springfox..*.*(..))")
	public Object controllerTargetMethod(ProceedingJoinPoint thisJoinPoint) {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		try {
			// application/json이 포함되지 않은 객체
			String content_header=request.getHeader("Content-Type")==null ?"" : request.getHeader("Content-Type");
			String accept_header=request.getHeader("Accept")==null ?"" : request.getHeader("Accept");
			log.debug("content-type:"+content_header);
			log.debug("accept:"+accept_header);
			boolean tf1=false;
			boolean tf2=false;
			boolean tf=false;
			
			if(content_header.contains("json") || content_header.contains("xml") ) {
				tf1=true;
			}else {
				tf1=false;
			}
			
			if(accept_header.contains("json") || accept_header.contains("xml")){ 
				tf2=true;
			}else {
				tf2=false;
			}
			
			if(tf1==true && tf2==false)tf=true;
			if(tf1==false && tf2==true)tf=true;
			if(tf1==false && tf2==false)tf=false;
			if(tf1==true && tf2==true)tf=true;
			
			if(tf==false) {
				log.debug("CALLED.. OBJECT");
				return thisJoinPoint.proceed();  
			}else {
				try {
					Object obj =  thisJoinPoint.proceed();
					if(obj instanceof ResponseEntity<?>) {
						log.debug("CALLED...RESTFul");
						//ResponseEntity<?> retVal = (ResponseEntity<?>) thisJoinPoint.proceed();
						log.debug("[API 응답메세지 처리] {} {} {} ", ((ResponseEntity<?>) obj).getBody(), ((ResponseEntity<?>) obj).getStatusCode() );
						
						RestResponse<Object> restResponse = (RestResponse<Object>) new RestResponse<>(((ResponseEntity<?>) obj).getBody()).userMessage("성공").resultCode(Integer.toString(((ResponseEntity<?>) obj).getStatusCodeValue())).httpStatusCode(((ResponseEntity<?>) obj).getStatusCode()+"");
						return new ResponseEntity<RestResponse<Object>>(restResponse, ((ResponseEntity<?>) obj).getStatusCode());
						
					}
					return obj;
				}catch(ClassCastException e) {
					throw new Exception("HTTP 요청이 잘 못 되었습니다.",e);
				}
			}
			
		
		} catch (Throwable e) {
			if (e instanceof NotFoundException) {
				throw NotFoundException.withUserMessage(e.getMessage())
						.withSystemMessage(((NotFoundException) e).getSystemMessage()).withCode("404").build();
			} else if (e instanceof BizException) {
				throw BizException.withSystemMessage(((BizException) e).getSystemMessage())
						.withUserMessage(((BizException) e).getUserMessage())
						.withForcesOK(((BizException) e).isForcesOK()).withCode(((BizException) e).getCode()).build();
			} else if (e instanceof ValidationException) {
				throw ValidationException.withSystemMessage(((ValidationException) e).getSystemMessage())
						.withUserMessage(((ValidationException) e).getUserMessage())
						.withCode(((ValidationException) e).getCode()).build();
			} else if (e instanceof UnauthorizedException) {
				throw UnauthorizedException.withSystemMessage(((UnauthorizedException) e).getSystemMessage())
						.withUserMessage(((UnauthorizedException) e).getUserMessage())
						.withCode(((UnauthorizedException) e).getCode()).build();
			} else if (e instanceof BizDuplicateException) {
				throw BizDuplicateException.withSystemMessage(((BizDuplicateException) e).getSystemMessage())
						.withUserMessage(((BizDuplicateException) e).getUserMessage())
						.withCode(((BizDuplicateException) e).getCode()).withForcesOK(true).build();
			} else {
				throw new RuntimeException(e);
			} 

		}
	}
}
